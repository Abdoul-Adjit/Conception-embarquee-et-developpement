#include "mbed.h"
#include "C12832.h"

/* Inputs */
DigitalIn U(p15);
DigitalIn D(p12);
DigitalIn L(p13);
DigitalIn R(p16);
DigitalIn X(p14);
Timer t;

/* Outputs */
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

C12832 lcd(p5, p7, p6, p8, p11);
DigitalOut leds[4]= {led1, led2, led3, led4};

Timer temps;

int val = 1;


void ShiftLeft()
{
    if(led1 == 1) {
        val = (val << 1);
        val = val +1;
        val = val & (15);
    } else {
        val = (val << 1);
    }
}

void LedOnLeft()
{
    if(val == 1) {
        val+=8;
    }
    for(int i = 0 ; i < 3 ; i++) {
        if(leds[i] == 1 and leds[i-1] == 0) {
            val += (1 << i);
            val = val & (15);
        }
    }

}
void LedOffLeft()
{
    for(int i = 0 ; i < 3 ; i++) {
        if(leds[i] == 1 and leds[i-1] == 0) {
            val -= (1>>i);
            val = val & (15);
        }
    }
}

void LedOnRight()
{
    bool ok;
    for(int i =3; i>0; i--) {
        if(leds[i] ==0 && leds[i-1] == 1) {
            val += (1<<i);
            ok = 1;
        } else {
            ok = 0;
        }
        if  (ok != 1) {
            leds[0] = 1;
        }
    }
}
void LedOffRight()
{
    bool ok;
    for(int i =3; i>0; i--) {
        if(leds[i] ==0 && leds[i-1] == 1) {
            val -= (1<<i);
            ok = 1;
        } else {
            ok = 0;
        }
        if  (ok != 1) {
            leds[0] = 0;
        }
    }
}

void ShiftRight()
{
    if(led4 == 1) {
        val = (val >> 1);
        val = val +8;
        val = val & (15);
    } else {
        val = (val >> 1);
    }
}

void DisplayIntLeds(int i)
{
    int reste = 0;
    int div = i;
    for (int x = 3 ; x>-1; x=x-1) {
        reste = div%2;
        div = div/2;
        leds[x] = reste;
    }
}

void PauseStop()
{
    temps.start();
    float a;
    while(X) {
        a = temps.read();
        if(a>3) {
            val = 0;
            return;
        }
    }
}

int main()
{
    bool flag_up = 0,flag_down = 0,way = 0; //way = 0 -> droite ; way = 1 -> gauche
    while(1) {
        if(way) {
            ShiftLeft();
        } else {
            ShiftRight();
        }
        if(L) {
            way = 1;
        }
        if(R) {
            way = 0;
        }
        if(U) {
            flag_up = 1;
        }
        if(D) {
            flag_down = 1;
        }
        if(flag_up) {
            if(way) {
                LedOnLeft();
            } else {
                LedOnRight();
            }
            DisplayIntLeds(val);
            flag_up = 0;
        }
        if(flag_down) {
            if(way) {
                LedOffLeft();
            } else {
                LedOffRight();
            }
            DisplayIntLeds(val);
            flag_down = 0;
        }
        DisplayIntLeds(val);
        wait(0.5);

    }
    return 0;
}
