#include "mbed.h"
#include "C12832.h"

/* Inputs */
DigitalIn U(p15);
DigitalIn D(p12);
DigitalIn L(p13);
DigitalIn R(p16);
DigitalIn X(p14);
Timer t;

/* Outputs */
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

C12832 lcd(p5, p7, p6, p8, p11);
DigitalOut leds[4]= {led1, led2, led3, led4};

Timer temps;

int val = 1;


void ShiftLeft()
{
    if(led1 == 1) {
        val = (val << 1);
        val = val +1;
        val = val & (15);
    } else {
        val = (val << 1);
    }
}

void LedOnLeft()
{
    if(val == 1) {
        val+=8;
    }
    for(int i = 0 ; i < 3 ; i++) {
        if(leds[i] == 1 and leds[i-1] == 0) {
            val += (1 << i);
            val = val & (15);
        }
    }

}
void LedOffLeft()
{
    for(int i = 0 ; i < 3 ; i++) {
        if(leds[i] == 1 and leds[i-1] == 0) {
            val -= (1>>i);
            val = val & (15);
        }
    }
}

void LedOnRight()
{
    bool ok;
    for(int i =3; i>0; i--) {
        if(leds[i] ==0 && leds[i-1] == 1) {
            val += (1<<i);
            ok = 1;
        } else {
            ok = 0;
        }
        if  (ok != 1) {
            leds[0] = 1;
        }
    }
}
void LedOffRight()
{
    bool ok;
    for(int i =3; i>0; i--) {
        if(leds[i] ==0 && leds[i-1] == 1) {
            val -= (1<<i);
            ok = 1;
        } else {
            ok = 0;
        }
        if  (ok != 1) {
            leds[0] = 0;
        }
    }
}

void ShiftRight()
{
    if(led4 == 1) {
        val = (val >> 1);
        val = val +8;
        val = val & (15);
    } else {
        val = (val >> 1);
    }
}

void DisplayIntLeds(int i)
{
    int reste = 0;
    int div = i;
    for (int x = 3 ; x>-1; x=x-1) {
        reste = div%2;
        div = div/2;
        leds[x] = reste;
    }
}

void PauseStop()
{
    temps.start();
    float a;
    while(X) {
        a = temps.read();
        if(a>3) {
            val = 0;
            return;
        }
    }
}

int main()
{
    int sens=0; // left = 0 right = 1
    while(1) {
        DisplayIntLeds(val);
        if(L) {
            sens = 0;
        }
        if(R) {
            sens = 1;
        }
        if(U and sens == 1) {
            LedOnRight();
        }
        if(D and sens == 1) {
            LedOffRight();
        }
        if(U and sens == 0) {
            LedOnLeft();
        }
        if(D and sens == 0) {
            LedOffLeft();
        }
        if(X) {
            PauseStop();
        }
        if (sens == 1) {
            ShiftRight();
        }
        if (sens == 0) {
            ShiftLeft();
        }
        wait(0.2);
    }
    return 0;
}
