#include "mbed.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

void ResetLeds()
{
    led1 = 0;
    led2 = 0;
    led3 = 0;
    led4 = 0;
}

void DisplayIntLeds(int i)
{
    int reste = 0;
    int div = i;
    DigitalOut led[4] = {led1,led2,led3,led4};
    for (int x = 3 ; x>-1; x=x-1) {
        reste = div%2;
        div = div/2;
        led[x] = reste;
    }
}


int main()
{
    ResetLeds();
    for (int i = 0 ; i<16 ; i = i+1) {
        DisplayIntLeds(i);
        wait(1);
    }
    ResetLeds();
}
