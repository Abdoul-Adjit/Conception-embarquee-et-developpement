#include "mbed.h"
#include "C12832.h"

/* Inputs */
DigitalIn U(p15);
DigitalIn D(p12);
DigitalIn L(p13);
DigitalIn R(p16);
DigitalIn X(p14);
Timer t;

/* Outputs */
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

C12832 lcd(p5, p7, p6, p8, p11);
DigitalOut leds[4]= {led1, led2, led3, led4};

Timer temps;
int level  = 1;

int x = 10, y = 10, cible_x = 64, cible_y = 16;
const int X_MAX = 128, Y_MAX = 32,X_MIN = 0, Y_MIN = 0;

void Gameover() {
    lcd.cls();
    lcd.locate(0,0);
    lcd.printf("Game over");
    x = 10 , y = 10;
    level = 1;
    temps.stop();
    temps.reset();
    temps.start();
    wait(2); 
}
void Right()
{
    
    while(x < X_MAX and (U == 0 and L == 0 and D == 0)) {
        float a = temps.read();
        if(a > 30) {
            Gameover();
        }
        if(x == cible_x and y == cible_y) {return;}
        x++;
        lcd.cls();
        lcd.fillcircle(x,y,2,1);
        lcd.circle(cible_x,cible_y,3,1);
        wait(0.1);
    }
}
void Left()
{
    while(x > X_MIN and (U == 0 and R == 0 and D == 0)) {
        float a = temps.read();
        if(a > 30) {Gameover();}
        if(x == cible_x and y == cible_y) {return;}
        x--;
        lcd.cls();
        lcd.fillcircle(x,y,2,1);
        lcd.circle(cible_x,cible_y,3,1);
        wait(0.1);
    }
}
void Down()
{
    while(y < Y_MAX and (U == 0 and L == 0 and R == 0)) {
        float a = temps.read();
        if(a > 30) {Gameover();}
        if(x == cible_x and y == cible_y) {return;}
        y++;
        lcd.cls();
        lcd.fillcircle(x,y,2,1);
        lcd.circle(cible_x,cible_y,3,1);
        if(x == cible_x and y == cible_y) {return;}
        wait(0.1);
    }
}
void Up()
{
    while(y > Y_MIN and (R == 0 and L == 0 and D == 0)) {
        float a = temps.read();
        if(a > 30) {Gameover();}
        if(x == cible_x and y == cible_y) {return;}
        y--;
        lcd.cls();
        lcd.fillcircle(x,y,2,1);
        lcd.circle(cible_x,cible_y,3,1);
        wait(0.1);
    }
}

void Win() {
    lcd.cls();
    lcd.locate(0,0);
    lcd.printf("Niveau %d",level);
    x = 10 , y = 10;
    wait(2);
    cible_x = rand() % 120;
    cible_y = rand() % 28;
    lcd.circle(cible_x,cible_y,3,1);
    temps.start();
}



int main()
{
    Win();
    lcd.fillcircle(x,y,2,1);
    lcd.circle(cible_x,cible_y,3,1);
    while(1) {
        if(x == cible_x and y == cible_y)
        {
            level++;
            Win();   
        }
        if(U) {
            Up();
        }
        if(D) {
            Down();
        }
        if(R) {
            Right();
        }
        if(L) {
            Left();
        }
        if(x == X_MAX-1) {Left();}
        if(x == X_MIN+1) {Right();}
        if(y == Y_MAX-1) {Down();}
        if(y == Y_MIN+1) {Up();}
        lcd.cls();
        lcd.circle(cible_x,cible_y,3,1);
        lcd.fillcircle(x,y,2,1);
        wait(0.1);
    }
}
