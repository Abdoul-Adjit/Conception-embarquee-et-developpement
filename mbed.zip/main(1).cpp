#include "mbed.h"
#include "LM75B.h"
#include "C12832.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

AnalogIn pot1(p19);
AnalogIn pot2(p20);

LM75B thermo(p28,p27);

C12832 lcd(p5, p7, p6, p8, p11);

int patterns[5] = {0,1,3,7,15};

PwmOut r (p23);
PwmOut g (p24);
PwmOut b (p25);


int AnalogIn2Index(float pot,int n)
{
    if(pot1 <0.2 and pot1 >=0.0) {
        return n-n;
    }
    if(pot1 <0.4 and pot1 >=0.2) {
        return n-4;
    }
    if(pot1 <0.6 and pot1 >=0.4) {
        return n-3;
    }
    if(pot1 <0.8 and pot1 >=0.6) {
        return n-2;
    }
    if(pot1 <= 1 and pot1 >=0.8) {
        return n-1;
    }

    return 0;
}

void ResetLeds()
{
    led1 = 0;
    led2 = 0;
    led3 = 0;
    led4 = 0;
}

void DisplayIntLeds(int i)
{
    int reste = 0;
    int div = i;
    DigitalOut led[4] = {led1,led2,led3,led4};
    for (int x = 3 ; x>-1; x=x-1) {
        reste = div%2;
        div = div/2;
        led[x] = reste;
    }
}

void R(float v)
{
    if (v <= 0.5 and v >0 ) {
        r = 1;
    } else {
        r =  1 - v ;
    }
}

void G(float v)
{
    if (v < 0.5 and v >= 0 ) {
        g = 1-v;
        if (v == 0.5) {g = 0;}
    } else {
        g = v;
    }
}

void B(float v)
{
    if (v >= 0.5 ) {b = 1;}
    else {
        b = 1-(0.5-v);
        }
}

int main()
{
    while(1) {
        lcd.cls();
        lcd.locate(0,0);
        lcd.printf("pot1  %f\npot2 %f\nthermo %f", pot1.read(),pot2.read(),thermo.read());
        DisplayIntLeds(patterns[AnalogIn2Index(pot1,5)]);
        R(pot2.read());
        B(pot2.read());
        G(pot2.read());

        wait(1);
    }
}
