#include "mbed.h"
#include "C12832.h"
#define DO  262.0
#define DOd 277.0
#define RE  294.0
#define REd 311.0
#define MI 330.0
#define FA  349.0
#define FAd 370.0
#define SOL  392.0
#define SOLd 415.0
#define LA  440.0
#define LAd 466.0
#define SI  494.0

DigitalOut myled(LED1);
Serial pc(USBTX,USBRX);
PwmOut spkr(p26);
AnalogIn pot1(p19);
AnalogIn pot2(p20);
C12832 lcd(p5, p7, p6, p8, p11);
float gammes[12] = {DO,DOd,RE,REd,MI,FA,FAd,SOL,SOLd,LA,LAd,SI};

int AnalogIn2Index(float pot,int n)
{
    float x = 1/(float)n, h=0;
    float tab[n+1];
    tab[0] = 0;
    for (int i = 1; i < n+1 ; i++) {
        h += x;
        tab[i] = h;
    }
    int gamme=0;
    for (int i = 1; i < n+1; i++) {
        if(pot >= tab[i-1] and pot < tab[i])
            gamme = i-1;
    }
    return gamme;
}

void playNote(float frequency, float volume)
{
    spkr.period(1.0/frequency);
    spkr = volume;
}
char lettres[7] = {'d','r','m','f','s','l','c'};

int find_letter(char a)
{
    for (int i=0; i< 7 ; i++) {
        if ( lettres[i]== a) {
            return i;
        }
    }
    return 0;
}

float notes[7] = {DO,RE,MI,FA,SOL,LA,SI};

int main()
{
    while(1) {
        float volume = pot1.read();
        char c = pc.getc();
        float note = notes[find_letter(c)];
        playNote(note,volume);
        lcd.cls();
        lcd.locate(0,0);
        lcd.printf("Volume = %f\nNote = %c",volume,c);
        wait(0.1);
    }
}
        //float val_pot2 = pot2.read();
        //float note = notes[AnalogIn2Index(val_pot2,7)];
        // protocole d'utilisation : choisir un volume puis donner une lettre.